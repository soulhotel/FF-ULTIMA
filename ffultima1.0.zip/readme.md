FF ULTIMA

a sequel to [Perfection FF CSS Theme] (https://github.com/soulhotel/Perfection-Firefox-CSS-Theme)

https://github.com/soulhotel/FF-CSS-ULTIMA

Modifications for power users

https://github.com/soulhotel/FF-CSS-ULTIMA/blob/main/Modification.md